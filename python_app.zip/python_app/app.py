from flask import Flask, url_for, render_template, redirect
from forms import PredictForm
from flask import request, sessions
import requests
# import json
# from start_transaction_request_builder import StartTransactionRequestBuilder
from flask import json
from flask import jsonify
from flask import Request
from flask import Response
import urllib3
import json
import xmltodict
import pprint
from bs4 import BeautifulSoup

# from flask_wtf import FlaskForm

app = Flask(__name__, instance_relative_config=False)
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.secret_key = '4216ea82-25ea-4f06-9a6d-31198e0522bc' #you will need a secret key

if __name__ == "__main__":
  app.run(debug=True, host='0.0.0.0')

@app.route('/', methods=('GET', 'POST'))

def startApp():
    form = PredictForm()
    return render_template('index.html', form=form)

@app.route('/predict', methods=('GET', 'POST'))
def predict():
    form = PredictForm()
    if form.submit():

        # NOTE: generate iam_token and retrieve ml_instance_id based on provided documentation
        header = {'Content-Type': 'application/json', 'Authorization': 'Bearer '
                 + "eyJraWQiOiIyMDIyMDkxMzA4MjciLCJhbGciOiJSUzI1NiJ9.eyJpYW1faWQiOiJJQk1pZC02NjUwMDJJOUxIIiwiaWQiOiJJQk1pZC02NjUwMDJJOUxIIiwicmVhbG1pZCI6IklCTWlkIiwianRpIjoiMjJhOWEwM2ItMmYxMS00NDMwLWJmNmMtOTAwOGFkYWQxM2Q3IiwiaWRlbnRpZmllciI6IjY2NTAwMkk5TEgiLCJnaXZlbl9uYW1lIjoiQW1yIiwiZmFtaWx5X25hbWUiOiJCZWxhc3kiLCJuYW1lIjoiQW1yIEJlbGFzeSIsImVtYWlsIjoiYW1yLmJlbGFzeUBzcHNzLW1lLmNvbSIsInN1YiI6ImFtci5iZWxhc3lAc3Bzcy1tZS5jb20iLCJhdXRobiI6eyJzdWIiOiJhbXIuYmVsYXN5QHNwc3MtbWUuY29tIiwiaWFtX2lkIjoiSUJNaWQtNjY1MDAySTlMSCIsIm5hbWUiOiJBbXIgQmVsYXN5IiwiZ2l2ZW5fbmFtZSI6IkFtciIsImZhbWlseV9uYW1lIjoiQmVsYXN5IiwiZW1haWwiOiJhbXIuYmVsYXN5QHNwc3MtbWUuY29tIn0sImFjY291bnQiOnsiYm91bmRhcnkiOiJnbG9iYWwiLCJ2YWxpZCI6dHJ1ZSwiYnNzIjoiMGQxZmY5OWNiYmZjNDRiOWE3YWZhNTk3MDc0ZjMwYzgiLCJpbXNfdXNlcl9pZCI6IjEwMzU2MDc3IiwiZnJvemVuIjp0cnVlLCJpbXMiOiIyNTg5NTA3In0sImlhdCI6MTY2NDcxNzg3MiwiZXhwIjoxNjY0NzIxNDcyLCJpc3MiOiJodHRwczovL2lhbS5jbG91ZC5pYm0uY29tL29pZGMvdG9rZW4iLCJncmFudF90eXBlIjoidXJuOmlibTpwYXJhbXM6b2F1dGg6Z3JhbnQtdHlwZTphcGlrZXkiLCJzY29wZSI6ImlibSBvcGVuaWQiLCJjbGllbnRfaWQiOiJkZWZhdWx0IiwiYWNyIjoxLCJhbXIiOlsicHdkIl19.b0gPMotmVi99spXjch0-72fGd_Q_52AQO4PJZJZ5PNX8caodlyO0ap5CJmgp-qBuijYfda4UEGUA2WJZY0s4-hV9Qom-LEgREUYA7aYNBDyjdUK7NrifTIDOzToE-4PCvP_Px1MnVZXMl2bt5x73oWvW2Ddsrmn8KqRb06SIjp9UDHBHCQOVXEU5hk6Dj5Sn97Xj5_f-Llh0wrKTux6rZrur4QJXxS0bY-TVP_K-zZhbVRwaywZ4g4yhA_kY-XS3tRHAarXYiXtE4_umOx3Be7vAqTr6VqjtYXF8B4NNmkskk4J0mSYzLFmjHTcKeIpZVFWU98PzFxcra3ByFBSwww"}

############## start parse XML SOAP and Extract Data values with input check valid #################
        xml = '''
        <?xml version="1.0" encoding="UTF-8"?>
        <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"  SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
        <SOAP-ENV:Body><SOAP-CHK:Success xmlns:SOAP-CHK = "http://soaptest1/soaptest/" xmlns="urn:candle-soap:attributes"><TABLE name="O4SRV.TSITSTSH">
        <OBJECT>Status_History</OBJECT>
        <DATA>
            <ROW>
                <row>70</row>
                <row>male</row>
                <row>100</row>
                <row>3</row>
                <row>yes</row>
                <row>egy</row>
            </ROW>
        </DATA>
        </TABLE>
        </SOAP-CHK:Success></SOAP-ENV:Body></SOAP-ENV:Envelope>
        '''

        soup = BeautifulSoup(xml, 'xml')
        userInput2 = []
        Terms = soup.select('ROW > row')
        # userInput2 = []
        for i in Terms:
          userInput2.append(i.text)
        print("data from xml: ", userInput2)
        age = int(userInput2[0])
        sex = str(userInput2[1])
        bmi = float(userInput2[2])
        children = int(userInput2[3])
        smoker = str(userInput2[4])
        region = str(userInput2[5])
        finall_userInput = [[age, sex, bmi, children, smoker, region]]
################ End Code ####################################################

      ############## start user input data code form ###################

        if(form.bmi.data == None): 
          python_object = []
        else:
          python_object = [form.age.data, form.sex.data, float(form.bmi.data),
            form.children.data, form.smoker.data, form.region.data]
        #Transform python objects to  Json

        userInput = []
        userInput.append(python_object)
      ################ End Code #########################

        # NOTE: manually define and pass the array(s) of values to be scored in the next line
        payload_scoring = {"input_data": [{"fields": ["age", "sex", "bmi",
          "children", "smoker", "region"], "values": finall_userInput }]}

        print(payload_scoring)

        response_scoring = requests.post("https://eu-gb.ml.cloud.ibm.com/ml/v4/deployments/4216ea82-25ea-4f06-9a6d-31198e0522bc/predictions?version=2022-09-28", json=payload_scoring, headers=header)

        output = json.loads(response_scoring.text)
        print(output)
        for key in output:
          ab = output[key]
        

        for key in ab[0]:
          bc = ab[0][key]
        
        roundedCharge = round(bc[0][0],2)
        # print("amr belasy")
        form.abc = roundedCharge # this returns the response back to the front page
        form.jsonf = output

        print(xmltodict.unparse(output, pretty=True))
        form.xml = xmltodict.unparse(output, pretty=True)

        return render_template('index.html', form=form)

        # my_xml = """
        #       <input_data>
        #         <fields>age</fields>
        #         <fields>sex</fields>
        #         <fields>bmi</fields>
        #         <fields>children</fields>
        #         <fields>smoker</fields>
        #         <fields>region</fields>
        #         <values>
        #           <row>34</row>
        #           <row>male</row>
        #           <row>56</row>
        #           <row>1</row>
        #           <row>no</row>
        #           <row>egy</row>
        #         </values>
        #       </input_data>
        # """

        # pp = pprint.PrettyPrinter(indent=4)
        # pp.pprint(json.dumps(xmltodict.parse(my_xml)))
        
